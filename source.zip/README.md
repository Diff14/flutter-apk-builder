# Colok Haptik V1

Starter project:
- Flutter Android client
- Login member/owner
- Haptik V1 / Haptik V2 / WATI selector
- In-app WebView
- Dark UI
- Theme selection
- Backend-driven config
- Owner command `/cakun nama password role`

## Flutter setup

Create a normal Flutter project, then copy `lib/` and merge the dependency section from `pubspec.yaml`.

Required package:
`webview_flutter`

Build:
`flutter pub get`
`flutter build apk --release`

## Backend

Node.js backend is in `backend/`.

Install:
`npm install`

Run:
`node server.js`

Set:
`PORT=8080`
`JWT_SECRET=change-this-secret`

For production, put the backend behind HTTPS/reverse proxy and change only:
`lib/config.dart`

Do not put DigitalOcean/Pterodactyl/API secrets in the APK.
