Builder should run flutter create --platforms=android . before build.
AndroidManifest needs INTERNET permission for API/WebView.
