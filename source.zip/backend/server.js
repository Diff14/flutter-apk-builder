const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

const app = express();
app.use(express.json());

const PORT = Number(process.env.PORT || 8080);
const JWT_SECRET = process.env.JWT_SECRET || 'CHANGE_ME_IN_PRODUCTION';

// Demo storage. Replace with PostgreSQL/SQLite for production.
const users = new Map();

const config = {
  links: {
    haptik_v1: 'https://example.com/haptik-v1',
    haptik_v2: 'https://example.com/haptik-v2',
    wati: 'https://example.com/wati'
  }
};

function auth(req, res, next) {
  const h = req.headers.authorization || '';
  const token = h.startsWith('Bearer ') ? h.slice(7) : null;
  if (!token) return res.status(401).json({error: 'Unauthorized'});
  try {
    req.user = jwt.verify(token, JWT_SECRET);
    next();
  } catch {
    res.status(401).json({error: 'Invalid token'});
  }
}

app.get('/health', (_, res) => res.json({ok: true}));

app.post('/api/login', async (req, res) => {
  const {username, password} = req.body || {};
  const u = users.get(username);
  if (!u || !(await bcrypt.compare(password || '', u.hash))) {
    return res.status(401).json({error: 'Username/password salah'});
  }
  const token = jwt.sign(
    {username: u.username, role: u.role},
    JWT_SECRET,
    {expiresIn: '7d'}
  );
  res.json({token, user: {username: u.username, role: u.role}});
});

app.get('/api/config', auth, (req, res) => {
  res.json({
    user: {username: req.user.username, role: req.user.role},
    links: config.links
  });
});

// Owner-only account creation endpoint.
// Console command integration can call this function from a Pterodactyl process wrapper.
app.post('/api/admin/create-user', auth, async (req, res) => {
  if (req.user.role !== 'owner') return res.status(403).json({error: 'Owner only'});
  const {username, password, role} = req.body || {};
  if (!username || !password || !['member', 'owner'].includes(role)) {
    return res.status(400).json({error: 'username/password/role tidak valid'});
  }
  if (users.has(username)) return res.status(409).json({error: 'User sudah ada'});
  users.set(username, {
    username,
    role,
    hash: await bcrypt.hash(password, 12)
  });
  res.json({ok: true, username, role});
});

app.listen(PORT, '0.0.0.0', () => {
  console.log(`Colok Haptik API listening on :${PORT}`);
});
