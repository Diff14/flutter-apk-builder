const express=require('express'),bcrypt=require('bcryptjs'),jwt=require('jsonwebtoken');
const app=express();app.use(express.json());const users=new Map();
const SECRET=process.env.JWT_SECRET||'CHANGE_ME';const PORT=process.env.PORT||8080;
const config={links:{haptik_v1:'https://example.com/haptik-v1',haptik_v2:'https://example.com/haptik-v2',wati:'https://example.com/wati'}};
function auth(req,res,next){const h=req.headers.authorization||'';try{if(!h.startsWith('Bearer '))throw 0;req.user=jwt.verify(h.slice(7),SECRET);next()}catch{res.status(401).json({error:'Unauthorized'})}}
app.get('/health',(q,s)=>s.json({ok:true}));
app.post('/api/login',async(req,res)=>{const {username,password}=req.body||{},u=users.get(username);
if(!u||!(await bcrypt.compare(password||'',u.hash)))return res.status(401).json({error:'Username/password salah'});
res.json({token:jwt.sign({username:u.username,role:u.role},SECRET,{expiresIn:'7d'}),user:{username:u.username,role:u.role}})});
app.get('/api/config',auth,(q,s)=>s.json({user:q.user,links:config.links}));
app.post('/api/admin/create-user',auth,async(req,res)=>{if(req.user.role!=='owner')return res.status(403).json({error:'Owner only'});
const {username,password,role}=req.body||{};if(!username||!password||!['member','owner'].includes(role))return res.status(400).json({error:'Invalid data'});
if(users.has(username))return res.status(409).json({error:'Exists'});users.set(username,{username,role,hash:await bcrypt.hash(password,12)});res.json({ok:true})});
app.listen(PORT,'0.0.0.0',()=>console.log('API on '+PORT));