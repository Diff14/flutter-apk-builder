For Android WebView:
Ensure INTERNET permission exists in android/app/src/main/AndroidManifest.xml:
<uses-permission android:name="android.permission.INTERNET"/>
