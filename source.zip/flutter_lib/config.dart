// The APK only needs the backend address here.
// Replace this with your HTTPS API endpoint.
const String backendUrl = 'https://api.example.com';
