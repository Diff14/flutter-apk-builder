import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:webview_flutter/webview_flutter.dart';
import 'config.dart';

void main() {
  runApp(const ColokHaptikApp());
}

class ColokHaptikApp extends StatefulWidget {
  const ColokHaptikApp({super.key});
  @override
  State<ColokHaptikApp> createState() => _AppState();
}

class _AppState extends State<ColokHaptikApp> {
  ThemeMode mode = ThemeMode.dark;
  void setTheme(ThemeMode value) => setState(() => mode = value);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Colok Haptik',
      themeMode: mode,
      darkTheme: ThemeData.dark(useMaterial3: true),
      theme: ThemeData(useMaterial3: true),
      home: LoginPage(onTheme: setTheme),
    );
  }
}

class Api {
  static Uri url(String path) => Uri.parse('$backendUrl$path');

  static Future<Map<String, dynamic>> login(String username, String password) async {
    final r = await http.post(
      url('/api/login'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'username': username, 'password': password}),
    );
    if (r.statusCode != 200) {
      throw Exception('Login gagal (${r.statusCode})');
    }
    return jsonDecode(r.body);
  }

  static Future<Map<String, dynamic>> config(String token) async {
    final r = await http.get(
      url('/api/config'),
      headers: {'Authorization': 'Bearer $token'},
    );
    if (r.statusCode != 200) {
      throw Exception('Gagal mengambil konfigurasi');
    }
    return jsonDecode(r.body);
  }
}

class LoginPage extends StatefulWidget {
  final void Function(ThemeMode) onTheme;
  const LoginPage({super.key, required this.onTheme});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final user = TextEditingController();
  final pass = TextEditingController();
  bool loading = false;
  String? error;

  Future<void> submit() async {
    setState(() { loading = true; error = null; });
    try {
      final data = await Api.login(user.text.trim(), pass.text);
      if (!mounted) return;
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (_) => HomePage(
            token: data['token'],
            username: data['user']['username'],
            role: data['user']['role'],
            onTheme: widget.onTheme,
          ),
        ),
      );
    } catch (e) {
      setState(() => error = e.toString().replaceFirst('Exception: ', ''));
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 430),
            child: Column(
              children: [
                const Icon(Icons.bolt_rounded, size: 72),
                const SizedBox(height: 12),
                const Text('COLOK HAPTIK',
                    style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                const Text('Member access', style: TextStyle(color: Colors.grey)),
                const SizedBox(height: 32),
                TextField(controller: user, decoration: const InputDecoration(labelText: 'Username')),
                const SizedBox(height: 12),
                TextField(
                  controller: pass,
                  obscureText: true,
                  decoration: const InputDecoration(labelText: 'Password'),
                ),
                if (error != null) ...[
                  const SizedBox(height: 12),
                  Text(error!, style: const TextStyle(color: Colors.redAccent)),
                ],
                const SizedBox(height: 22),
                SizedBox(
                  width: double.infinity,
                  child: FilledButton(
                    onPressed: loading ? null : submit,
                    child: Text(loading ? 'Loading...' : 'LOGIN'),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class HomePage extends StatefulWidget {
  final String token;
  final String username;
  final String role;
  final void Function(ThemeMode) onTheme;

  const HomePage({
    super.key,
    required this.token,
    required this.username,
    required this.role,
    required this.onTheme,
  });

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  Map<String, dynamic>? cfg;
  String? error;

  @override
  void initState() {
    super.initState();
    loadConfig();
  }

  Future<void> loadConfig() async {
    try {
      final c = await Api.config(widget.token);
      if (mounted) setState(() => cfg = c);
    } catch (e) {
      if (mounted) setState(() => error = e.toString());
    }
  }

  void openFlow(String title, String url) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => WebFlowPage(title: title, url: url),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final links = cfg?['links'] ?? {};
    return Scaffold(
      appBar: AppBar(
        title: const Text('Colok Haptik'),
        actions: [
          PopupMenuButton<String>(
            onSelected: (v) {
              if (v == 'dark') widget.onTheme(ThemeMode.dark);
              if (v == 'light') widget.onTheme(ThemeMode.light);
            },
            itemBuilder: (_) => const [
              PopupMenuItem(value: 'dark', child: Text('Dark')),
              PopupMenuItem(value: 'light', child: Text('Light')),
            ],
          )
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Text('Halo, ${widget.username}',
              style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
          Text(widget.role.toUpperCase(), style: const TextStyle(color: Colors.grey)),
          const SizedBox(height: 22),
          if (error != null) Text(error!),
          _tile('Haptik V1', Icons.flash_on, links['haptik_v1'], openFlow),
          _tile('Haptik V2', Icons.flash_on, links['haptik_v2'], openFlow),
          _tile('WATI', Icons.chat_bubble_outline, links['wati'], openFlow),
          const SizedBox(height: 10),
          _simple('Store', Icons.storefront),
          _simple('VPS', Icons.dns),
          _simple('Pterodactyl', Icons.dashboard),
          _simple('Script', Icons.code),
          _simple('Global Chat', Icons.forum),
        ],
      ),
    );
  }

  Widget _tile(String title, IconData icon, dynamic url,
      void Function(String, String) action) {
    final enabled = url is String && url.isNotEmpty;
    return Card(
      child: ListTile(
        leading: Icon(icon),
        title: Text(title),
        subtitle: Text(enabled ? 'Connect in-app' : 'Not configured'),
        trailing: const Icon(Icons.chevron_right),
        enabled: enabled,
        onTap: enabled ? () => action(title, url) : null,
      ),
    );
  }

  Widget _simple(String title, IconData icon) {
    return Card(
      child: ListTile(
        leading: Icon(icon),
        title: Text(title),
        trailing: const Icon(Icons.chevron_right),
        onTap: () => ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text('$title module siap dihubungkan ke backend.'))),
      ),
    );
  }
}

class WebFlowPage extends StatefulWidget {
  final String title;
  final String url;
  const WebFlowPage({super.key, required this.title, required this.url});

  @override
  State<WebFlowPage> createState() => _WebFlowPageState();
}

class _WebFlowPageState extends State<WebFlowPage> {
  late final WebViewController controller;

  @override
  void initState() {
    super.initState();
    controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setNavigationDelegate(NavigationDelegate(
        onNavigationRequest: (request) => NavigationDecision.navigate,
      ))
      ..loadRequest(Uri.parse(widget.url));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.title)),
      body: WebViewWidget(controller: controller),
    );
  }
}
