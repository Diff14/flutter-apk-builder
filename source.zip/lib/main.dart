import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:webview_flutter/webview_flutter.dart';
import 'config.dart';

void main()=>runApp(const App());

class App extends StatefulWidget{const App({super.key});@override State<App> createState()=>_AppState();}
class _AppState extends State<App>{
  ThemeMode mode=ThemeMode.dark;
  @override Widget build(BuildContext c)=>MaterialApp(
    debugShowCheckedModeBanner:false,title:'Colok Haptik',themeMode:mode,
    theme:ThemeData(useMaterial3:true),darkTheme:ThemeData.dark(useMaterial3:true),
    home:Login(onTheme:(m)=>setState(()=>mode=m)));
}

class Api{
  static Uri u(String p)=>Uri.parse('$backendUrl$p');
  static Future<Map<String,dynamic>> login(String user,String pass)async{
    final r=await http.post(u('/api/login'),headers:{'Content-Type':'application/json'},
      body:jsonEncode({'username':user,'password':pass}));
    if(r.statusCode!=200)throw Exception('Login gagal');
    return jsonDecode(r.body);
  }
  static Future<Map<String,dynamic>> config(String token)async{
    final r=await http.get(u('/api/config'),headers:{'Authorization':'Bearer $token'});
    if(r.statusCode!=200)throw Exception('Config gagal');
    return jsonDecode(r.body);
  }
}

class Login extends StatefulWidget{
  final void Function(ThemeMode) onTheme; const Login({super.key,required this.onTheme});
  @override State<Login> createState()=>_LoginState();
}
class _LoginState extends State<Login>{
  final u=TextEditingController(),p=TextEditingController(); bool busy=false; String? err;
  Future<void> go()async{
    setState(()=>busy=true);
    try{
      final d=await Api.login(u.text.trim(),p.text);
      if(!mounted)return;
      Navigator.pushReplacement(context,MaterialPageRoute(builder:(_)=>Home(
        token:d['token'],username:d['user']['username'],role:d['user']['role'],onTheme:widget.onTheme)));
    }catch(e){setState(()=>err=e.toString().replaceFirst('Exception: ',''));}
    finally{if(mounted)setState(()=>busy=false);}
  }
  @override Widget build(BuildContext c)=>Scaffold(body:Center(child:SingleChildScrollView(
    padding:const EdgeInsets.all(24),child:ConstrainedBox(constraints:const BoxConstraints(maxWidth:430),
    child:Column(children:[
      const Icon(Icons.bolt,size:72),const Text('COLOK HAPTIK',style:TextStyle(fontSize:28,fontWeight:FontWeight.bold)),
      const SizedBox(height:25),TextField(controller:u,decoration:const InputDecoration(labelText:'Username')),
      const SizedBox(height:12),TextField(controller:p,obscureText:true,decoration:const InputDecoration(labelText:'Password')),
      if(err!=null)Padding(padding:const EdgeInsets.all(10),child:Text(err!,style:const TextStyle(color:Colors.red))),
      SizedBox(width:double.infinity,child:FilledButton(onPressed:busy?null:go,child:Text(busy?'LOGIN...':'LOGIN')))
    ])))));
}

class Home extends StatefulWidget{
  final String token,username,role; final void Function(ThemeMode) onTheme;
  const Home({super.key,required this.token,required this.username,required this.role,required this.onTheme});
  @override State<Home> createState()=>_HomeState();
}
class _HomeState extends State<Home>{
  Map<String,dynamic>? cfg; String? err;
  @override void initState(){super.initState();load();}
  Future<void> load()async{try{final x=await Api.config(widget.token);if(mounted)setState(()=>cfg=x);}
    catch(e){if(mounted)setState(()=>err=e.toString());}}
  void open(String t,String u)=>Navigator.push(context,MaterialPageRoute(builder:(_)=>WebPage(t,u)));
  @override Widget build(BuildContext c){
    final links=(cfg?['links'] as Map?)?.cast<String,dynamic>()??{};
    return Scaffold(appBar:AppBar(title:const Text('Colok Haptik'),actions:[PopupMenuButton<String>(
      onSelected:(v)=>widget.onTheme(v=='light'?ThemeMode.light:ThemeMode.dark),
      itemBuilder:(_)=>const[PopupMenuItem(value:'dark',child:Text('Dark')),PopupMenuItem(value:'light',child:Text('Light'))])]),
      body:ListView(padding:const EdgeInsets.all(16),children:[
        Text('Halo, ${widget.username}',style:const TextStyle(fontSize:22,fontWeight:FontWeight.bold)),
        Text(widget.role.toUpperCase()),if(err!=null)Text(err!),
        tile('Haptik V1',links['haptik_v1']),tile('Haptik V2',links['haptik_v2']),tile('WATI',links['wati']),
        tile('Store',null),tile('VPS',null),tile('Pterodactyl',null),tile('Script',null),tile('Global Chat',null)
      ]));
  }
  Widget tile(String title,dynamic url)=>Card(child:ListTile(
    leading:const Icon(Icons.apps),title:Text(title),subtitle:Text(url is String?'Connect in-app':'Backend module'),
    trailing:const Icon(Icons.chevron_right),enabled:url is String&&url.isNotEmpty,
    onTap:url is String&&url.isNotEmpty?()=>open(title,url):null));
}

class WebPage extends StatefulWidget{
  final String title,url; const WebPage(this.title,this.url,{super.key});
  @override State<WebPage> createState()=>_WebPageState();
}
class _WebPageState extends State<WebPage>{
  late final WebViewController c;
  @override void initState(){super.initState();c=WebViewController()
    ..setJavaScriptMode(JavaScriptMode.unrestricted)
    ..setNavigationDelegate(NavigationDelegate(onNavigationRequest:(_)=>NavigationDecision.navigate))
    ..loadRequest(Uri.parse(widget.url));}
  @override Widget build(BuildContext x)=>Scaffold(appBar:AppBar(title:Text(widget.title)),body:WebViewWidget(controller:c));
}
